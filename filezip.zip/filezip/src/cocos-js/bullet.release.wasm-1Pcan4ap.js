System.register([],(function(e){"use strict";return{execute:function(){e("default","")}}}));
